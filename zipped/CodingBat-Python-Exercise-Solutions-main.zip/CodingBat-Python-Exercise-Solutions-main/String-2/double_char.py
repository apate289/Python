# https://codingbat.com/prob/p170842

def double_char(str):
  doubled_str = ""
  for char in str:
    doubled_str += (2 * char)
    
  return doubled_str
