# https://codingbat.com/prob/p167246

def count_hi(str):
  # Trivial if you know your string methods
  return str.count("hi")
