#  https://codingbat.com/prob/p164876

def cat_dog(str):
  # Trivial if you know your string methods
  return (str.count("cat") == str.count("dog"))
