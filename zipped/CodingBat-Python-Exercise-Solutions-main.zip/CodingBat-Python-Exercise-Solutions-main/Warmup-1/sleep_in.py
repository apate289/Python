# https://codingbat.com/prob/p173401

def sleep_in(weekday, vacation):
  if (weekday):
    return vacation
    
  else:
    return True
    