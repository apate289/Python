# https://codingbat.com/prob/p147920

def front3(str):
  
  if (len(str) < 3):
    return (str * 3)
    
  else:
    return (str[0:3] * 3)