# https://codingbat.com/prob/p141905

def sum_double(a, b):
  return (a+b) if (a != b) else (2*(a+b))