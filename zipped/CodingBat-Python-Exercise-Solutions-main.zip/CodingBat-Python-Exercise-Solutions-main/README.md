# About

My annotated solutions to the CodingBat Python exercises.

https://codingbat.com/python

There's one .py file for each exercise that contains the problem URL, and the solution.


## Showing thanks

If these solutions were helpful to you, please feel free to express your gratitude!

<a href="https://www.buymeacoffee.com/raleighlittles" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/default-orange.png" alt="Buy Me A Coffee" height="41" width="174"></a>
