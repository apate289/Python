# https://codingbat.com/prob/p182144

def make_abba(a, b):
  return (a + (b * 2) + a)
