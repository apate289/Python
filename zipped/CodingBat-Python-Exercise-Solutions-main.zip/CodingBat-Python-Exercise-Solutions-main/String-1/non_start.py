# https://codingbat.com/prob/p127703

def non_start(a, b):
  return a[1:len(a)] + b[1:len(b)]
