# https://codingbat.com/prob/p160545

def left2(str):
  return (str[2:len(str)] + str[0:2])
