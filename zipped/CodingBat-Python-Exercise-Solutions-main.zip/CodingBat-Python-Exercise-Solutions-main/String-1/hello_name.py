# https://codingbat.com/prob/p115413

def hello_name(name):
  return "Hello " + name + "!"
