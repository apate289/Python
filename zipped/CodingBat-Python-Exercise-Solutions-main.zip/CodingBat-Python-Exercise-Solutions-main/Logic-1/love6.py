# https://codingbat.com/prob/p100958

def love6(a, b):
  return ((abs(a-b) == 6) or (a == 6) or (b == 6) or (a+b ==6))
