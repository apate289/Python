# https://codingbat.com/prob/p191645

def sum3(nums):
  # Easy if you know your built-ins
  return sum(nums)