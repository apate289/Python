# https://codingbat.com/prob/p171011

def middle_way(a, b):
  # length agnostic
  return [a[len(a) // 2], b[len(b) // 2]]
