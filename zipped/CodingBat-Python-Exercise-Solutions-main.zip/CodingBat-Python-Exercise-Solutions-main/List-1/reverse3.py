# https://codingbat.com/prob/p192962

def reverse3(nums):
  # Does this count as cheating?
  return nums[::-1]
