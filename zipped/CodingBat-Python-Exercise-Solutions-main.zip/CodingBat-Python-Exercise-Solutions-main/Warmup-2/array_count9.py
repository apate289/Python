# https://codingbat.com/prob/p166170

def array_count9(nums):
  # Kind of a hack if you know your builtins...
  return nums.count(9)
