# https://codingbat.com/prob/p193507

def string_times(str, n):
  # String multiplication operator
  return (str * n)
