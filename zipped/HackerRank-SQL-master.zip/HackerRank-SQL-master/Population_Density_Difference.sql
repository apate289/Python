/* Use maximum and minimum functions here, then just take the difference.
 */
SELECT MAX(POPULATION) - MIN(POPULATION) FROM CITY