/*
 * Combine the round and average functions to get a rounded average of the population.
 */
SELECT ROUND(AVG(POPULATION)) FROM CITY 