/* 
 * Use the boolean AND to combine our conditions inside the WHERE clause. 
 */
SELECT NAME FROM CITY WHERE POPULATION > 120000 AND COUNTRYCODE = "USA"