# About

Annotated solutions to HackerRank's SQL domain questions. https://www.hackerrank.com/domains/sql?badge_type=sql

Mostly written in MySQL unless otherwise stated.
