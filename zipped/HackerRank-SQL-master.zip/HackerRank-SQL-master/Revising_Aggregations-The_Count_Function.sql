/*
 * Identical to other Revising Aggregations examples, but with a different aggregator function.
 * 
 */ 
SELECT COUNT(NAME) FROM CITY WHERE POPULATION > 100000