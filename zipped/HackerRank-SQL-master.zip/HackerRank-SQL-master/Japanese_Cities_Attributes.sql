/* Per the problem, country code for Japan is "JPN". */
SELECT * FROM CITY WHERE COUNTRYCODE = "JPN"