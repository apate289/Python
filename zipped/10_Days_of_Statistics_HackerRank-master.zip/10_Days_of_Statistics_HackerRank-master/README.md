# About
Solutions to HackerRank's [10 Days of Statistics](https://www.hackerrank.com/domains/tutorials/10-days-of-statistics) challenge, written mostly in Python 2.
