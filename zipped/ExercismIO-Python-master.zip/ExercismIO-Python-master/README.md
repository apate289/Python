# About

Annotated solutions to selected Exercism IO's Python challenges.
