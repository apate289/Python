# About
I wanted to review my Python, so I went through HackerRank's [Python](https://www.hackerrank.com/domains/python/py-introduction) challenge.

## Show thanks!

If my HackerRank solutions were helpful to you, feel free to show your gratitude.

<a href="https://www.buymeacoffee.com/raleighlittles" target="_blank"><img src="https://cdn.buymeacoffee.com/buttons/default-orange.png" alt="Buy Me A Coffee" height="41" width="174"></a>
