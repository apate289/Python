x, k = map(int, input().split())

print( eval(input()) == k)