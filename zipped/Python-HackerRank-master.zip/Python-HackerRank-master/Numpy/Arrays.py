def arrays(arr):
    # complete this function
    # use numpy.array 
    a = numpy.array(arr, float)
    return a[::-1]

