import numpy


my_array = numpy.array(input().split(), int)
print(numpy.reshape(my_array,(3,3)))

