def split_and_join(line):
    # write your code here
    return "-".join((line.split()))