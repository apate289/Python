def print_full_name(a, b):
    first_name = a
    last_name = b
    
    print("Hello", first_name, last_name + "!", "You just delved into python.")