if __name__ == '__main__':
    n = int(input())
    
    for i in range(0, n):
        print(i**2)
