if __name__ == '__main__':
    n = int(input())
    full_str = ""
    for i in range(1, n+1):
        full_str += str(i)
    print(full_str)    
        
