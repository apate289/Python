import calendar # Don't reinvent the wheel
def is_leap(year):
    # Write your logic here
    return calendar.isleap(year)