if __name__ == '__main__':
    a = int(input())
    b = int(input())
    
    print(str(a+b))
    print(str(a-b))
    print(str(a*b))
