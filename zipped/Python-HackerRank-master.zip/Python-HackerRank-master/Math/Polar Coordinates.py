import cmath
# Make sure to use the * to unpack the tuple
print(*cmath.polar(complex(input())), sep='\n')